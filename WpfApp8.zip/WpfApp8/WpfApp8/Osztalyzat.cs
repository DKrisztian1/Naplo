﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp8
{
    public class Osztalyzat
    {
        String nev;
        String tantargy;
        String datum;
        int jegy;

        public Osztalyzat(string nev, string tantargy, string datum, int jegy)
        {
            this.nev = nev;
            this.tantargy = tantargy;
            this.datum = datum;
            this.jegy = jegy;
        }

        public string Nev { get => nev;}
        public string Tantargy { get => tantargy;}
        public string Datum { get => datum;}
        public int Jegy { get => jegy;}
    }
}
