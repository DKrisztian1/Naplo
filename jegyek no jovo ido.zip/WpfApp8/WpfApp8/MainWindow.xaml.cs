﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Osztalyzat> jegyek = new List<Osztalyzat>();
        DateTime maiNap = DateTime.Now;

        public MainWindow()
        {
            InitializeComponent();
            dpDatum.DisplayDateEnd = maiNap;
        }

        private void Rogzit(object sender, RoutedEventArgs e)
        {
            StreamWriter sw = new StreamWriter("jegyek.csv", append: true);
            if (txtNev.Text != "")
            {
                sw.WriteLine($"{txtNev.Text};{cboTantargy.SelectionBoxItem};{dpDatum.Text};{sliJegy.Value}");
                sw.Close();
            }
            else
                MessageBox.Show("Nem adtál meg nevet!");
        }

        private void NaploBetoltese(object sender, RoutedEventArgs e)
        {
            StreamReader sr = new StreamReader("jegyek.csv");
            while (!sr.EndOfStream)
            {
                string[] adatok = sr.ReadLine().Split(';');

                Osztalyzat ujJegy = new Osztalyzat(adatok[0], adatok[1], adatok[2], int.Parse(adatok[3]));
                jegyek.Add(ujJegy);
            }
            sr.Close();
            dgNaplo.ItemsSource = jegyek;
        }
    }
}
